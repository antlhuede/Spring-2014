
#define DLLEXPORT extern "C" __declspec(dllexport)
