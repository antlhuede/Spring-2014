#pragma once

#include <string>
#include <vector>
#include <windows.h>
#include <stdio.h>
#include <map>
typedef const char * cstr;

