
#include "Standard.h"
#include "PlugInManager.h"

void PlugInManager::AddPlugIn(PlugIn* plugIn)
{

}
