#include "TestClass.h"
TestClass::TestClass()
{

}

TestClass::~TestClass()
{

}

int  TestClass::GetValue()
{
  return value;
}
void TestClass::SetValue()
{

}