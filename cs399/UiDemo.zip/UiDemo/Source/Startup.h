
namespace Framework
{

class CoreEngine;
CoreEngine* CreateGame(HWND parent);
void ShutdownGame();

}
